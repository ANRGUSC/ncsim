"""Bounded rerun of public-v1 experiments with the corrected production model.

No existing result or paper directory is modified. Legacy generators are inputs,
not executable experiment drivers. Original shortest-path intent is made explicit
as minimum-hop routing; solo MAC goodput replaces the raw-PHY baseline.
"""
import copy
import hashlib
import importlib.util
import json
import logging
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT/'experiments/paper_revision')]
from run_revision_experiments import Case, run_case
from workloads import _build_dag
from ncsim.models.network import Network, Node, Link, Position
from ncsim.models.routing import MinimumHopRouting
from ncsim.models.wireless import configure_wireless
from ncsim.scheduler.saga_adapter import create_scheduler
from ncsim.core.simulation import Simulation

OUT = ROOT/'experiments/paper_revision/results_minimal'
INPUT = ROOT/'experiments/paper_revision/inputs/minimal'
AUTHOR = Path('C:/Users/bhask/claude/ncsim-main')

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def network(nodes, links):
    return Network(nodes={n['id']: Node(n['id'], n['compute_capacity'], Position(n['x'], n['y'])) for n in nodes},
                   links={l['id']: Link(l['id'], l['from'], l['to'], l['bandwidth']) for l in links})

def main():
    if os.environ.get('PYTHONHASHSEED') != '0':
        return subprocess.call([sys.executable, __file__], env=dict(os.environ, PYTHONHASHSEED='0'))
    logging.disable(logging.WARNING)
    OUT.mkdir(parents=True, exist_ok=True)
    INPUT.mkdir(parents=True, exist_ok=True)
    if not (OUT/'protected_hashes.json').exists():
        paths = list((ROOT/'paper/arxiv_version').rglob('*')) + list((ROOT/'paper/revision').rglob('*'))
        paths += [ROOT/'output/pdf/ncsim_arxiv_review.pdf', ROOT/'output/pdf/ncsim_sec_review.pdf']
        (OUT/'protected_hashes.json').write_text(json.dumps({str(p.relative_to(ROOT)):sha(p) for p in paths if p.is_file()}, indent=2))
    sources = [ROOT/'paper/scripts/run_full_scheduler_comparison.py', ROOT/'paper/scripts/run_sensitivity_ccr.py',
               AUTHOR/'paper/scripts/run_scalability_rgg.py']
    # Frozen copies make reproduction independent of the author's home path.
    for source in sources:
        target=INPUT/source.name
        if not target.exists():shutil.copy2(source,target)
    if not (INPUT/'sources.json').exists():
        (INPUT/'sources.json').write_text(json.dumps({p.name:{'source':str(p),'sha256':sha(INPUT/p.name)} for p in sources},indent=2))
    recorded=json.loads((INPUT/'sources.json').read_text())
    assert all(sha(INPUT/name)==item['sha256'] for name,item in recorded.items())
    grid = module('public_grid', INPUT/sources[0].name)
    ccr = module('public_ccr', INPUT/sources[1].name)
    scale = module('public_scale', INPUT/sources[2].name)
    payload = {'grid':[], 'ccr':[], 'multidag':[], 'scalability':[]}
    started = time.perf_counter()
    for size in (2,3,4):
        net = network(*grid.generate_network(size))
        for dag_name, generator in grid.DAG_GENERATORS.items():
            for routing in ('minimum_hop','widest_path'):
                case_id = f'grid{size}_{dag_name}_{routing}'
                case = Case(case_id, f'grid{size}',42,{'nodes':len(net.nodes),'links':len(net.links)},
                            net,dag_name,42,_build_dag(case_id,*generator()),routing)
                payload['grid'].extend(run_case(case,schedulers=('heft','cpop','round_robin')))
        print(f'Original grid {size}x{size}: complete',flush=True)
    # Preserve the separate CCR study's capacity sequence and graph generator.
    for dag_name, (_, generator) in ccr.DAG_GENERATORS.items():
        for mb in ccr.DATA_SIZES:
            case_id=f'ccr_{dag_name}_{mb:g}'
            net=network(*ccr.generate_network())
            case=Case(case_id,'ccr_grid3',42,{},net,dag_name,42,_build_dag(case_id,*generator(mb)))
            for row in run_case(case,schedulers=('heft',)):
                row['payload_MB']=mb
                payload['ccr'].append(row)
    for count in range(1,6):
        for mode in ('solo_80211','full_wireless'):
            net=network(*ccr.generate_network())
            setup=configure_wireless(net,mode,seed=42)
            routing=MinimumHopRouting()
            sim=Simulation(net,create_scheduler('heft',routing=routing),routing_model=routing,
                           interference_model=setup.interference_model,seed=42)
            for i in range(count):
                sim.inject_dag(_build_dag(f'dag{i}',*ccr._make_dag_small(10.0)),inject_at=.5*i)
            result=sim.run()
            payload['multidag'].append({'count':count,'mode':mode,'status':result.status,
                'makespan_s':result.makespan if result.status=='completed' else None,
                'placements':{k:v.assignments for k,v in sim.engine.placement_plans.items()}})
    print('Original CCR and multi-DAG: complete',flush=True)
    net=network(*scale.generate_rgg(100,500,42))
    for size in (30,40,50):
        for routing in ('minimum_hop','widest_path'):
            case_id=f'rgg100_{size}_{routing}'
            case=Case(case_id,'original_rgg100',42,{'nodes':100,'links':len(net.links)},net,
                      f'pipeline{size}',42,_build_dag(case_id,*getattr(scale,f'_make_dag_{size}')()),routing)
            payload['scalability'].extend(run_case(case,schedulers=('heft','cpop','round_robin')))
        print(f'Original RGG, {size} tasks: complete',flush=True)
    payload['provenance']={'elapsed_s':time.perf_counter()-started,'python':sys.version,
        'production_sha256':{str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'ncsim').rglob('*.py')},
        'script_sha256':sha(Path(__file__)),'seed':42,'PYTHONHASHSEED':'0',
        'changes':'Current production model; normalized solo baseline; minimum-hop routing; FIFO placement execution.'}
    (OUT/'original_scale_results.json').write_text(json.dumps(payload,indent=2,allow_nan=False))
    print({k:len(v) for k,v in payload.items() if isinstance(v,list)},flush=True)
    print(f'Finished in {payload["provenance"]["elapsed_s"]:.1f}s',flush=True)
    return 0

if __name__=='__main__':
    raise SystemExit(main())
